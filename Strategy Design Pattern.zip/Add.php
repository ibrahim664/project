<?php
    require_once("I-operation.php");
    class Add implements IOperation
    {
	    function doOperation(int $x, int $y)
        {
            return $x + $y;
        }
	}
?>