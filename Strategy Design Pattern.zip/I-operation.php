<?php 
    interface Ioperation
    {
        function doOperation(int $x, int $y);
    }
    
?>