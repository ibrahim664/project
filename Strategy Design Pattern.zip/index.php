<?php 
    require_once("Calculator.php");
    require_once("Add.php");
    require_once("Multiply.php");

    $calc = new caclculator(new Add);
    echo "1 + 2 = ".$calc->executestrate(1, 2);

    $calc = new caclculator(new Multiply);
    echo "<br> 3 * 2 = ".$calc->executestrate(3, 2);
?>