<?php 
    require_once("I-operation.php");
    class Multiply implements IOperation
    {
        function doOperation(int $x, int $y) 
        {
            return $x * $y;
        }
    }
?>