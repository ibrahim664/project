<?php 
    require_once("I-operation.php");
    class caclculator
    {
        private $Ioperation;
        public function __construct($Ioperation)
        {
            $this->Ioperation = $Ioperation;
        }
        public function executestrate($x, $y)
        {
            return $this->Ioperation->doOperation($x, $y);
        }
    }
?>